# ⚡ CampusPulse — Intelligent Campus Signal & Announcement Hub
> **Hackathon Track:** Fork KUET 2026 | **Team:** Code & Caffeine  
> **Problem Statement:** *"One Campus, A Thousand Tiny Announcements"*

---

## 🎯 The Problem

> *"A student wakes up and discovers that the class location changed. Another student missed a club registration because the announcement was buried in a group chat. Someone knows about an event because their friend happened to mention it. Another person never hears about it at all. Information exists everywhere—but reaching the right person at the right time is the real problem."*

Campus communication today suffers from three fundamental flaws:
1. **Critical Signals Get Buried in Noise:** Urgent updates (e.g. classroom relocations, rescheduled exams) get drowned out in noisy group chats and unorganized boards.
2. **Irrelevant Information Overload:** 90% of announcements broadcast to all students are irrelevant to a specific student (e.g., 4th-year ME notices broadcast to 1st-year CSE students).
3. **No Proof of Reach / Zero Accountability:** Faculty and Class Representatives (CRs) never know if students actually saw a critical notice until people show up in the wrong room.

---

## 💡 The CampusPulse Solution

**CampusPulse** is an intelligent, zero-noise announcement and signal routing system designed to deliver the right update to the right person at the exact right moment.

### 🌟 Core Innovations

| Innovation | How it Solves the Problem |
| :--- | :--- |
| **🚨 Emergency Flash Alert & Audio Chime** | Critical room shifts or exam reschedules trigger a high-visibility sticky banner, Web Audio API dual-tone chime, and instant WebSocket push. |
| **🎯 Hyper-Personalized Signal Engine** | Announcements are scoped by Department, Batch, Section, Clubs, and Halls. A 3rd-year CSE student only receives updates directly applicable to their courses and activities. |
| **📉 Real-Time Noise Reduction Meter** | Measures and displays how much noise has been filtered out for the active student (e.g. *"38% noise blocked for CSE 21-A"*). |
| **✅ Acknowledgment Receipts ("Proof of Reach")** | Critical announcements feature an **"Acknowledge / Got It"** button. CRs and Professors see real-time counters (e.g. *"48/50 students acknowledged"*). |
| **⏳ Deadline Radar & Calendar Sync** | Action items and club registration deadlines feature live countdown timers and 1-click **Add to Calendar (.ics)** export for Google Calendar, Apple Calendar, and Outlook. |
| **🌅 Morning Briefing / Executive Digest** | Replaces 50 scattered chat notifications with an AI-curated 30-second morning briefing summarizing today's room shifts, deadlines, and key notices. |
| **⚡ Urgency Threshold Slider** | Allows students during exam week to set their filter to **Strict** (Critical & High urgency only), silencing all casual updates. |

---

## 👥 Built-in Realistic Personas (1-Click Testable)

CampusPulse includes 5 pre-seeded personas representing the diverse ecosystem of an engineering campus:

1. **Arafat Rahman** (`CSE`, Batch 21, Section A, Lalon Shah Hall, Cyber Security Club):
   - Immediately sees the critical room shift from Room 302 to NAB-405, the Cyber HackFest deadline, and the OS assignment.
2. **Tasnim Islam** (`EEE`, Batch 23, Section B, Rokeya Hall, Robotics Club Exec):
   - Sees the EEE-2202 Circuit Lab reschedule to 2:30 PM and the ROS2 Robotics Workshop.
3. **Dr. Farhan Tanvir** (Associate Professor & Course Teacher):
   - Publisher mode: Broadcasts verified official notices with targeted audience criteria.
4. **Tanveer Hasan** (Class Representative - CSE 21):
   - Monitors student acknowledgment rates on class announcements.
5. **Sabbir Ahmed** (`ME`, Batch 22, Section A, Amar Ekushey Hall, Sports Club):
   - Demonstrates how non-relevant CSE/EEE departmental notices are automatically filtered out.

---

## 🛠️ Technical Stack & Architecture

- **Backend Runtime:** [Deno 2](https://deno.com/) with native TypeScript.
- **Embedded Database:** Built-in `node:sqlite` for persistent, relational storage with zero external dependencies.
- **Real-Time Layer:** Native WebSockets (`Deno.upgradeWebSocket`) for instant notification dispatch and live acknowledgment sync.
- **Audio Engine:** Browser Web Audio API dual-tone synthesizer (no external MP3/audio files required).
- **Calendar Standard:** RFC 5545 `.ics` iCalendar generator for universal device calendar integration.
- **Frontend:** Responsive, zero-framework Single Page Application with custom glassmorphic CSS design system, dark/light theme support, and micro-animations.

---

## 🚀 Running & Testing CampusPulse

### Prerequisites
- [Deno 2](https://deno.com/) installed (already pre-installed in the environment).

### 1. Start the Web Application
```bash
deno task start
```
The application will start immediately at **`http://localhost:8000`**.

### 2. Run Automated Integration Tests
```bash
deno run --allow-read --allow-write test.ts
```
Runs the 5 integration test suites verifying database seeding, audience personalization, noise reduction ratios, acknowledgment tracking, morning briefing compilation, and iCalendar generation.

---

## 🏆 Key Features Demonstrated in the UI

1. **Emergency Banner**: Located at the top of the feed when critical notices are active.
2. **Feed Switcher**:
   - `🎯 For Me`: Scoped to the active student persona.
   - `🌐 Campus Explore`: University-wide public noticeboard.
   - `⏳ Deadlines`: Sorted by nearest upcoming submission or registration cutoff.
   - `🏛️ Official`: Verified administration notices only.
   - `⭐ Saved`: Bookmarked posts.
3. **Urgency Filter**: Toggle between `Strict`, `Balanced`, and `All`.
4. **Morning Briefing Modal**: Click "Morning Briefing" in the header or sidebar to view the daily synthesized overview.
5. **Publisher Modal**: Click "+ Post Notice" to simulate broadcasting a critical alert or club event with audience filtering.
