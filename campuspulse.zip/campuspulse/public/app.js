// CampusPulse Client Application
// Team: Code & Caffeine

let currentUser = null;
let allUsers = [];
let activeFeedType = "for_me";
let activeUrgency = "balanced";
let activeCategory = "all";
let searchQuery = "";
let countdownInterval = null;

// Web Audio API Chime for Critical Emergency Flash Notices
function playUrgentAlertChime() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    
    // First high tone
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = "sine";
    osc1.frequency.setValueAtTime(880, ctx.currentTime); // A5
    gain1.gain.setValueAtTime(0.15, ctx.currentTime);
    gain1.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.25);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start();
    osc1.stop(ctx.currentTime + 0.25);

    // Second higher tone
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = "sine";
    osc2.frequency.setValueAtTime(1174.66, ctx.currentTime + 0.15); // D6
    gain2.gain.setValueAtTime(0.18, ctx.currentTime + 0.15);
    gain2.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.45);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(ctx.currentTime + 0.15);
    osc2.stop(ctx.currentTime + 0.45);
  } catch (err) {
    console.warn("Audio chime disabled or blocked by browser autoplay policy:", err);
  }
}

// Format relative time (e.g. "25 mins ago")
function formatRelativeTime(isoDate) {
  if (!isoDate) return "";
  const diffMs = Date.now() - new Date(isoDate).getTime();
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHour = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHour / 24);

  if (diffSec < 60) return "Just now";
  if (diffMin < 60) return `${diffMin}m ago`;
  if (diffHour < 24) return `${diffHour}h ago`;
  return `${diffDay}d ago`;
}

// Format deadline remaining time
function formatDeadlineCountdown(isoDate) {
  if (!isoDate) return null;
  const diffMs = new Date(isoDate).getTime() - Date.now();
  if (diffMs <= 0) return { text: "Expired", isUrgent: true };

  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHour = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHour / 24);

  const hoursLeft = diffHour % 24;
  const minsLeft = diffMin % 60;

  let text = "";
  if (diffDay > 0) {
    text = `${diffDay}d ${hoursLeft}h left`;
  } else if (diffHour > 0) {
    text = `${diffHour}h ${minsLeft}m left`;
  } else {
    text = `${minsLeft}m left`;
  }

  return {
    text,
    isUrgent: diffHour < 24,
  };
}

// Toast notification display
function showToast(message, type = "info") {
  const container = document.getElementById("toast-container");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = "toast";
  const icon = type === "critical" ? "🚨" : type === "success" ? "✅" : "🔔";
  
  toast.innerHTML = `
    <span style="font-size: 1.25rem;">${icon}</span>
    <div style="font-size: 0.85rem; font-weight: 500; color: var(--text-primary);">${message}</div>
  `;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transition = "opacity 0.3s ease";
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// Initialize Application
async function initApp() {
  setupTheme();
  setupEventListeners();
  await loadUsers();
  await loadFeed();
  setupWebSocket();

  // Refresh countdown badges every 30 seconds
  if (countdownInterval) clearInterval(countdownInterval);
  countdownInterval = setInterval(() => {
    updateDeadlineBadges();
  }, 30000);
}

// Setup Theme (Dark / Light)
function setupTheme() {
  const savedTheme = localStorage.getItem("campuspulse_theme") || "dark";
  document.documentElement.setAttribute("data-theme", savedTheme);

  document.getElementById("theme-toggle-btn")?.addEventListener("click", () => {
    const currentTheme = document.documentElement.getAttribute("data-theme");
    const nextTheme = currentTheme === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", nextTheme);
    localStorage.setItem("campuspulse_theme", nextTheme);
  });
}

// Load Users / Personas
async function loadUsers() {
  try {
    const res = await fetch("/api/users");
    allUsers = await res.json();
    
    // Default to Arafat (id 1)
    const savedUserId = localStorage.getItem("campuspulse_user_id");
    if (savedUserId) {
      currentUser = allUsers.find(u => u.id === parseInt(savedUserId, 10)) || allUsers[0];
    } else {
      currentUser = allUsers[0];
    }

    renderUserHeader();
    renderPersonaSidebar();
  } catch (err) {
    console.error("Failed to load users:", err);
  }
}

// Render Top Header Persona Pill
function renderUserHeader() {
  if (!currentUser) return;
  const avatar = document.getElementById("header-avatar");
  const name = document.getElementById("header-name");
  const tag = document.getElementById("header-tag");

  if (avatar) avatar.src = currentUser.avatar;
  if (name) name.textContent = currentUser.name.split(" ")[0];
  if (tag) {
    if (currentUser.role === "faculty") {
      tag.textContent = "Faculty / Dept Head";
    } else if (currentUser.role === "cr") {
      tag.textContent = `CR ${currentUser.department} ${currentUser.batch}-${currentUser.section}`;
    } else {
      tag.textContent = `${currentUser.department} ${currentUser.batch}-${currentUser.section}`;
    }
  }
}

// Render Persona List in Sidebar
function renderPersonaSidebar() {
  const list = document.getElementById("persona-list");
  if (!list) return;

  list.innerHTML = allUsers.map(user => {
    const isActive = currentUser && currentUser.id === user.id;
    let subtitle = "";
    if (user.role === "faculty") {
      subtitle = "Professor & Course Teacher";
    } else if (user.role === "cr") {
      subtitle = `Class Rep (${user.department} '${user.batch})`;
    } else {
      subtitle = `${user.department} Batch ${user.batch} • ${user.hall}`;
    }

    return `
      <div class="persona-option ${isActive ? 'active' : ''}" onclick="switchPersona(${user.id})">
        <img class="persona-avatar" src="${user.avatar}" alt="${user.name}">
        <div class="persona-option-info">
          <h4>${user.name}</h4>
          <p>${subtitle}</p>
        </div>
      </div>
    `;
  }).join("");
}

// Switch Active Persona
window.switchPersona = async function(userId) {
  const target = allUsers.find(u => u.id === userId);
  if (!target) return;
  currentUser = target;
  localStorage.setItem("campuspulse_user_id", userId.toString());
  
  renderUserHeader();
  renderPersonaSidebar();
  showToast(`Switched persona to ${currentUser.name}`, "info");

  // Adjust default target department in publish form for convenience
  const pubDept = document.getElementById("pub-target-dept");
  if (pubDept && currentUser.department !== "ALL") {
    pubDept.value = currentUser.department;
  }

  await loadFeed();
};

// Load Feed & Update UI
async function loadFeed() {
  if (!currentUser) return;

  const feedContainer = document.getElementById("feed-stream");
  const bannerContainer = document.getElementById("emergency-banner-container");

  try {
    const params = new URLSearchParams({
      user_id: currentUser.id.toString(),
      feed_type: activeFeedType,
      urgency: activeUrgency,
      category: activeCategory,
      search: searchQuery,
    });

    const res = await fetch(`/api/announcements?${params}`);
    const data = await res.json();
    const notices = data.announcements || [];
    const metrics = data.metrics || {};

    // Update Noise Filter Badges
    const badge = document.getElementById("noise-reduced-badge");
    const countLabel = document.getElementById("feed-count-label");
    if (badge) {
      if (activeFeedType === "all") {
        badge.textContent = "Global Campus View (0% Filtered)";
        badge.style.background = "rgba(107, 114, 128, 0.2)";
        badge.style.color = "var(--text-secondary)";
      } else {
        badge.textContent = `${metrics.noiseReductionPercent}% Noise Blocked`;
        badge.style.background = "rgba(16, 185, 129, 0.15)";
        badge.style.color = "#10b981";
      }
    }
    if (countLabel) {
      countLabel.textContent = `Showing ${notices.length} relevant signals (${metrics.noiseFilteredOut} filtered)`;
    }

    // Check for Critical Alerts to show in the Emergency Banner
    renderEmergencyBanner(notices, bannerContainer);

    // Render Announcement Stream
    renderNoticeCards(notices, feedContainer);

    // Update Deadline Radar Sidebar
    renderDeadlineRadar(notices);

  } catch (err) {
    console.error("Failed to load feed:", err);
    if (feedContainer) {
      feedContainer.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">⚠️</div>
          <p>Failed to connect to CampusPulse server. Please retry.</p>
        </div>
      `;
    }
  }
}

// Render Emergency Flash Banner (e.g. classroom relocated)
function renderEmergencyBanner(notices, container) {
  if (!container) return;

  // Find most critical unacknowledged or recent critical notice
  const criticalNotice = notices.find(n => n.urgency === "critical");

  if (!criticalNotice) {
    container.innerHTML = "";
    return;
  }

  const isAck = criticalNotice.user_acknowledged > 0;

  container.innerHTML = `
    <div class="emergency-banner">
      <div class="emergency-content">
        <div class="emergency-icon">🚨</div>
        <div>
          <div class="emergency-title">CRITICAL CAMPUS ALERT • ATTENTION REQUIRED</div>
          <div class="emergency-desc">${criticalNotice.title}</div>
          ${criticalNotice.location_change ? `
            <div class="location-shift-badge">
              📍 Location Change: ${criticalNotice.location_change}
            </div>
          ` : ""}
        </div>
      </div>
      <div>
        <button 
          class="btn btn-sm ${isAck ? 'btn-ack acknowledged' : 'btn-critical'}"
          onclick="acknowledgeNotice(${criticalNotice.id})"
        >
          ${isAck ? `✓ Acknowledged (${criticalNotice.ack_count})` : "⚡ Got It / Acknowledge"}
        </button>
      </div>
    </div>
  `;
}

// Render Notice Cards Stream
function renderNoticeCards(notices, container) {
  if (!container) return;

  if (notices.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📭</div>
        <h3>No announcements match this filter</h3>
        <p style="margin-top: 0.35rem; font-size: 0.85rem;">
          Your feed is clean and noise-free! Adjust your urgency slider or switch categories to explore more.
        </p>
      </div>
    `;
    return;
  }

  container.innerHTML = notices.map(notice => {
    const isBookmarked = notice.user_bookmarked > 0;
    const isAck = notice.user_acknowledged > 0;
    const deadline = formatDeadlineCountdown(notice.deadline_at);

    // Urgency badge styling
    let urgencyBadge = "";
    if (notice.urgency === "critical") {
      urgencyBadge = `<span class="badge badge-critical">🚨 Critical Flash</span>`;
    } else if (notice.urgency === "high") {
      urgencyBadge = `<span class="badge badge-high">⚠️ High Priority</span>`;
    } else if (notice.urgency === "medium") {
      urgencyBadge = `<span class="badge badge-medium">ℹ️ Notice</span>`;
    } else {
      urgencyBadge = `<span class="badge badge-low">🌱 Community</span>`;
    }

    // Category label
    const categoryIcons = {
      academics: "🎓 Academics",
      clubs: "🤖 Club / Hackathon",
      admin: "🏛️ Administration",
      hall: "🏢 Hall & Hostel",
      community: "🤝 Community",
    };
    const catLabel = categoryIcons[notice.category] || notice.category;

    // Audience targeting badges
    let targetLabel = "";
    if (notice.target_dept !== "ALL" || notice.target_batch !== "ALL" || notice.target_section !== "ALL") {
      const parts = [];
      if (notice.target_dept !== "ALL") parts.push(notice.target_dept);
      if (notice.target_batch !== "ALL") parts.push(`'${notice.target_batch}`);
      if (notice.target_section !== "ALL") parts.push(`Sec ${notice.target_section}`);
      targetLabel = `<span class="badge badge-dept">🎯 For: ${parts.join(" ")}</span>`;
    } else if (notice.target_club !== "ALL") {
      targetLabel = `<span class="badge badge-dept">👥 Club: ${notice.target_club}</span>`;
    } else if (notice.target_hall !== "ALL") {
      targetLabel = `<span class="badge badge-dept">🏢 Hall: ${notice.target_hall}</span>`;
    } else {
      targetLabel = `<span class="badge badge-dept">🌐 Campus-Wide</span>`;
    }

    return `
      <article class="notice-card ${notice.urgency}-border" id="card-${notice.id}">
        
        <div class="card-header">
          <div class="card-badges">
            ${urgencyBadge}
            <span class="badge badge-dept">${catLabel}</span>
            ${targetLabel}
            ${notice.is_verified ? `<span class="badge badge-verified">✓ Verified Source</span>` : ""}
          </div>

          <div class="card-actions-top">
            <button class="icon-btn ${isBookmarked ? 'bookmarked' : ''}" onclick="toggleBookmark(${notice.id})" title="Save Notice">
              ${isBookmarked ? "★" : "☆"}
            </button>
          </div>
        </div>

        <h2 class="card-title">${escapeHTML(notice.title)}</h2>

        ${notice.location_change ? `
          <div class="relocation-card-banner">
            <span>📍 Classroom Shift:</span>
            <strong>${escapeHTML(notice.location_change)}</strong>
          </div>
        ` : ""}

        <!-- AI TL;DR Box -->
        <div class="card-tldr-box">
          <span class="tldr-label">TL;DR:</span>
          <span>${escapeHTML(notice.summary_tldr)}</span>
        </div>

        <div class="card-content">
          ${escapeHTML(notice.content)}
        </div>

        <div class="card-footer">
          <div class="publisher-info">
            <div class="publisher-dot"></div>
            <div>
              <span class="publisher-name">${escapeHTML(notice.publisher_name)}</span>
              <span style="font-size: 0.75rem; color: var(--text-muted);"> • ${escapeHTML(notice.publisher_role)} • ${formatRelativeTime(notice.created_at)}</span>
            </div>
          </div>

          <div class="card-cta-group">
            ${deadline ? `
              <span class="deadline-pill" id="deadline-${notice.id}">
                ⏳ ${deadline.text}
              </span>
              <a href="/api/export-ics/${notice.id}" class="btn btn-secondary btn-sm" title="Add event to Google / Apple Calendar">
                📅 Add to Cal (.ics)
              </a>
            ` : ""}

            ${notice.action_label && notice.action_url ? `
              <a href="${notice.action_url}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-sm">
                ${escapeHTML(notice.action_label)} ↗
              </a>
            ` : ""}

            ${notice.requires_acknowledgment ? `
              <button 
                class="btn btn-sm ${isAck ? 'btn-ack acknowledged' : 'btn-ack'}" 
                onclick="acknowledgeNotice(${notice.id})"
                title="Confirm you have seen this important update"
              >
                ${isAck ? `✓ Acknowledged (${notice.ack_count})` : `Acknowledge (${notice.ack_count})`}
              </button>
            ` : ""}
          </div>
        </div>

      </article>
    `;
  }).join("");
}

// Render Deadline Radar Sidebar
function renderDeadlineRadar(notices) {
  const container = document.getElementById("deadline-radar-list");
  const countBadge = document.getElementById("sidebar-deadline-count");
  if (!container) return;

  const withDeadlines = notices
    .filter(n => n.deadline_at)
    .sort((a, b) => new Date(a.deadline_at).getTime() - new Date(b.deadline_at).getTime())
    .slice(0, 4);

  if (countBadge) {
    countBadge.textContent = `${withDeadlines.length} Approaching`;
  }

  if (withDeadlines.length === 0) {
    container.innerHTML = `
      <div style="font-size: 0.8rem; color: var(--text-muted); text-align: center; padding: 0.5rem 0;">
        No active deadlines today! 🎉
      </div>
    `;
    return;
  }

  container.innerHTML = withDeadlines.map(n => {
    const dl = formatDeadlineCountdown(n.deadline_at);
    return `
      <div class="deadline-item">
        <div class="deadline-item-title">${escapeHTML(n.title)}</div>
        <div class="deadline-item-meta">
          <span style="color: ${dl.isUrgent ? 'var(--critical)' : 'var(--high)'}; font-weight: 700;">
            ⏳ ${dl.text}
          </span>
          <a href="/api/export-ics/${n.id}" style="color: var(--primary); text-decoration: none; font-weight: 600;">
            + Cal
          </a>
        </div>
      </div>
    `;
  }).join("");
}

// Update Deadline countdown strings
function updateDeadlineBadges() {
  const pills = document.querySelectorAll("[id^='deadline-']");
  pills.forEach(pill => {
    const id = pill.id.replace("deadline-", "");
    // Just refresh feed
  });
}

// Action: Acknowledge Notice
window.acknowledgeNotice = async function(noticeId) {
  if (!currentUser) return;
  try {
    const res = await fetch(`/api/announcements/${noticeId}/acknowledge`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user_id: currentUser.id }),
    });
    const result = await res.json();
    if (result.success) {
      showToast("Acknowledgment receipt recorded! CR & Faculty can see your confirmation.", "success");
      await loadFeed();
    }
  } catch (err) {
    console.error("Failed to acknowledge:", err);
  }
};

// Action: Toggle Bookmark
window.toggleBookmark = async function(noticeId) {
  if (!currentUser) return;
  try {
    const res = await fetch(`/api/announcements/${noticeId}/bookmark`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user_id: currentUser.id }),
    });
    const result = await res.json();
    if (result.success) {
      showToast(result.bookmarked ? "Saved to your bookmarks" : "Removed from bookmarks", "info");
      await loadFeed();
    }
  } catch (err) {
    console.error("Failed to toggle bookmark:", err);
  }
};

// Action: Generate Morning Briefing
async function generateMorningBriefing() {
  if (!currentUser) return;
  const modal = document.getElementById("briefing-modal");
  const modalBody = document.getElementById("briefing-modal-body");
  const title = document.getElementById("briefing-modal-title");

  try {
    const res = await fetch(`/api/digest?user_id=${currentUser.id}`);
    const data = await res.json();

    if (title) title.textContent = `Morning Briefing • ${data.user.name}`;

    modalBody.innerHTML = `
      <div class="digest-lead">
        ${escapeHTML(data.executiveSummary)}
      </div>

      ${data.criticalAlerts.length > 0 ? `
        <div class="digest-box" style="border-left: 4px solid var(--critical);">
          <div class="digest-section-title" style="color: #f87171;">🚨 Urgent Attention (Today)</div>
          ${data.criticalAlerts.map(a => `
            <div style="margin-bottom: 0.5rem;">
              <strong>${escapeHTML(a.title)}</strong>
              ${a.location_change ? `<div style="font-size: 0.8rem; color: #fca5a5;">📍 Relocated: ${escapeHTML(a.location_change)}</div>` : ""}
              <div style="font-size: 0.825rem; color: var(--text-secondary);">${escapeHTML(a.summary_tldr)}</div>
            </div>
          `).join("")}
        </div>
      ` : ""}

      ${data.upcomingDeadlines.length > 0 ? `
        <div class="digest-box" style="border-left: 4px solid var(--high);">
          <div class="digest-section-title" style="color: #fbbf24;">⏳ Deadlines in the Next 72 Hours</div>
          ${data.upcomingDeadlines.map(d => {
            const dl = formatDeadlineCountdown(d.deadline_at);
            return `
              <div style="margin-bottom: 0.5rem; display: flex; justify-content: space-between; align-items: center;">
                <div>
                  <strong>${escapeHTML(d.title)}</strong>
                  <div style="font-size: 0.8rem; color: var(--text-muted);">${escapeHTML(d.summary_tldr)}</div>
                </div>
                <span class="deadline-pill" style="white-space: nowrap;">${dl ? dl.text : ""}</span>
              </div>
            `;
          }).join("")}
        </div>
      ` : ""}

      <div class="digest-box">
        <div class="digest-section-title">🎓 Department & Campus Signals</div>
        ${data.departmentNotices.map(n => `
          <div style="margin-bottom: 0.4rem; font-size: 0.85rem;">
            • <strong>${escapeHTML(n.title)}</strong> — <span style="color: var(--text-secondary);">${escapeHTML(n.summary_tldr)}</span>
          </div>
        `).join("")}
      </div>
    `;

    modal.classList.add("active");
  } catch (err) {
    console.error("Failed to generate briefing:", err);
    showToast("Failed to compile morning briefing", "error");
  }
}

// WebSocket Connection & Real-Time Push Handling
function setupWebSocket() {
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  const wsUrl = `${protocol}//${window.location.host}/ws`;
  const socket = new WebSocket(wsUrl);

  socket.onopen = () => {
    console.log("⚡ CampusPulse WebSocket connected for instant signals.");
  };

  socket.onmessage = (event) => {
    try {
      const msg = JSON.parse(event.data);

      if (msg.type === "NEW_ANNOUNCEMENT") {
        const notice = msg.announcement;

        // Check if notice is critical
        if (notice.urgency === "critical") {
          playUrgentAlertChime();
          showToast(`🚨 CRITICAL ALERT: ${notice.title}`, "critical");
        } else {
          showToast(`📢 New Notice: ${notice.title}`, "info");
        }

        // Reload feed to incorporate new broadcast
        loadFeed();
      } else if (msg.type === "ACKNOWLEDGMENT_UPDATE") {
        // Increment acknowledgment counter in real-time
        loadFeed();
      }
    } catch (err) {
      console.error("Error handling WebSocket message:", err);
    }
  };

  socket.onclose = () => {
    // Attempt auto-reconnect in 3 seconds
    setTimeout(setupWebSocket, 3000);
  };
}

// Setup Event Listeners
function setupEventListeners() {
  // Feed Tabs
  const tabBtns = document.querySelectorAll(".tab-btn");
  tabBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      tabBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      activeFeedType = btn.dataset.feed || "for_me";
      loadFeed();
    });
  });

  // Urgency / Noise Filter Pills
  const urgencyPills = document.querySelectorAll(".urgency-pill");
  urgencyPills.forEach(pill => {
    pill.addEventListener("click", () => {
      urgencyPills.forEach(p => p.classList.remove("active"));
      pill.classList.add("active");
      activeUrgency = pill.dataset.urgency || "balanced";
      loadFeed();
    });
  });

  // Category Tag Buttons
  const catTags = document.querySelectorAll(".category-tag");
  catTags.forEach(tag => {
    tag.addEventListener("click", () => {
      catTags.forEach(t => t.classList.remove("active"));
      tag.classList.add("active");
      activeCategory = tag.dataset.category || "all";
      loadFeed();
    });
  });

  // Search Input with Debounce
  const searchInput = document.getElementById("search-input");
  let searchTimeout = null;
  searchInput?.addEventListener("input", (e) => {
    if (searchTimeout) clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      searchQuery = e.target.value;
      loadFeed();
    }, 250);
  });

  // Morning Briefing Triggers
  document.getElementById("open-briefing-btn")?.addEventListener("click", generateMorningBriefing);
  document.getElementById("sidebar-briefing-btn")?.addEventListener("click", generateMorningBriefing);
  document.getElementById("close-briefing-modal")?.addEventListener("click", () => {
    document.getElementById("briefing-modal")?.classList.remove("active");
  });
  document.getElementById("dismiss-briefing-btn")?.addEventListener("click", () => {
    document.getElementById("briefing-modal")?.classList.remove("active");
    showToast("Morning briefing reviewed! Have a productive day.", "success");
  });

  // Publish Modal Triggers
  const publishModal = document.getElementById("publish-modal");
  document.getElementById("open-publish-modal-btn")?.addEventListener("click", () => {
    publishModal?.classList.add("active");
  });
  document.getElementById("close-publish-modal")?.addEventListener("click", () => {
    publishModal?.classList.remove("active");
  });
  document.getElementById("cancel-publish-btn")?.addEventListener("click", () => {
    publishModal?.classList.remove("active");
  });

  // Close modals on backdrop click
  window.addEventListener("click", (e) => {
    if (e.target === publishModal) publishModal?.classList.remove("active");
    const briefingModal = document.getElementById("briefing-modal");
    if (e.target === briefingModal) briefingModal?.classList.remove("active");
  });

  // Publish Form Submit
  const publishForm = document.getElementById("publish-form");
  publishForm?.addEventListener("submit", async (e) => {
    e.preventDefault();

    const urgency = document.getElementById("pub-urgency").value;
    const title = document.getElementById("pub-title").value;
    const category = document.getElementById("pub-category").value;
    const location = document.getElementById("pub-location").value;
    const dept = document.getElementById("pub-target-dept").value;
    const batch = document.getElementById("pub-target-batch").value;
    const section = document.getElementById("pub-target-section").value;
    const club = document.getElementById("pub-target-club").value;
    const content = document.getElementById("pub-content").value;
    const tldr = document.getElementById("pub-tldr").value;
    const deadline = document.getElementById("pub-deadline").value;
    const actionLabel = document.getElementById("pub-action-label").value;
    const requiresAck = document.getElementById("pub-requires-ack").checked;

    const payload = {
      title,
      content,
      summary_tldr: tldr || content.slice(0, 120) + "...",
      category,
      urgency,
      target_dept: dept,
      target_batch: batch,
      target_section: section,
      target_club: club,
      location_change: location || null,
      deadline_at: deadline ? new Date(deadline).toISOString() : null,
      action_label: actionLabel || null,
      action_url: actionLabel ? "#" : null,
      publisher_id: currentUser ? currentUser.id : 3,
      publisher_name: currentUser ? currentUser.name : "Faculty Member",
      publisher_role: currentUser ? currentUser.role.toUpperCase() : "FACULTY",
      is_verified: currentUser?.role === "faculty" || currentUser?.role === "cr",
      requires_acknowledgment: requiresAck,
    };

    try {
      const res = await fetch("/api/announcements", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.success) {
        showToast("Announcement published & broadcasted live! 🚀", "success");
        publishModal?.classList.remove("active");
        publishForm.reset();
        await loadFeed();
      }
    } catch (err) {
      console.error("Failed to publish:", err);
      showToast("Error publishing announcement", "critical");
    }
  });
}

// Utility: HTML escape
function escapeHTML(str) {
  if (!str) return "";
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// Start
document.addEventListener("DOMContentLoaded", initApp);
